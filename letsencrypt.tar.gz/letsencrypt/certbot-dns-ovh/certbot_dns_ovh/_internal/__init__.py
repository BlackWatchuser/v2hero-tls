"""Internal implementation of `~certbot_dns_ovh.dns_ovh` plugin."""
